/*
 * okai JS — kernel glue (DOM bridge scaffold + script runner)
 *
 * "tinyjs ok edition (tm)": substantially rewritten C port of TinyJS
 * (gfwilliams/tiny-js + MarcoLizza/tiny-js) adapted to the freestanding
 * okernel. This file is the kernel-facing layer: it owns the global engine
 * instance, registers the print()/console.log() builtins, exposes a minimal
 * `document` object, and extracts <script> blocks from fetched HTML.
 *
 * MIT — derived from TinyJS (C) 2009 Pur3 Ltd, Gordon Williams.
 */
#include "js.h"
#include "serial.h"

/* The single shared browser engine instance (lazily created by js_run). */
js_tiny *g_js_engine = 0;

/* ---- print() / console.log() ------------------------------------------- */
static void scPrint(js_var *c, void *userdata) {
    (void)userdata;
    char buf[4096];
    js_var_get_string(js_var_get_parameter(c, "jsCode"), buf, sizeof(buf));
    serial_printf("[js] %s\n", buf);
}
static void scConsoleLog(js_var *c, void *userdata) {
    (void)userdata;
    char buf[4096];
    js_var_get_string(js_var_get_parameter(c, "jsCode"), buf, sizeof(buf));
    serial_printf("[js] %s\n", buf);
}

/* ---- document.getElementById(id) -> element stub ----------------------- */
/* Each id maps to a memoized element object with settable textContent/style.
 * NOTE: mutating these does not yet re-drive okai's token-based DOM render —
 * that is the deeper T3 DOM-bridge work. This scaffold lets scripts run and
 * call the DOM API without crashing. */
static js_var *js_dom_get_element(const char *id) {
    js_tiny *t = g_js_engine;
    char key[128];
    int i = 0;
    while (id[i] && i < (int)sizeof(key) - 1) { key[i] = id[i]; i++; }
    key[i] = 0;
    js_var *el = js_var_get_child(t->root, key);
    if (el) return el;
    el = js_var_new_blank(JS_V_OBJECT);
    js_var_add_child(t->root, key, el);
    /* element.textContent (string) */
    js_var_add_child(el, "textContent", js_var_new_string(""));
    /* element.style (object: color, backgroundColor, ...) */
    js_var *style = js_var_new_blank(JS_V_OBJECT);
    js_var_add_child(el, "style", style);
    return el;
}
static void scGetElementById(js_var *c, void *userdata) {
    (void)userdata;
    char id[256];
    js_var_get_string(js_var_get_parameter(c, "id"), id, sizeof(id));
    js_var *el = js_dom_get_element(id);
    js_var_copy_value(js_var_get_return_var(c), el);
}

/* ---- engine lifecycle -------------------------------------------------- */
void js_init(void) {
    if (g_js_engine) return;
    g_js_engine = js_create();
    registerFunctions(g_js_engine);
    registerMathFunctions(g_js_engine);
    js_add_native(g_js_engine, "function print(jsCode)", scPrint, 0);
    js_add_native(g_js_engine, "function console.log(jsCode)", scConsoleLog, 0);
    js_add_native(g_js_engine, "function document.getElementById(id)", scGetElementById, 0);
}

/* Run a script; surface any error to the serial console. */
void js_run(const char *code) {
    if (!g_js_engine) js_init();
    js_execute(g_js_engine, code);
    if (js_has_error(g_js_engine)) {
        serial_printf("[js] ERROR: %s\n", g_js_engine->error);
    }
}

/* Extract <script>...</script> blocks from raw HTML and execute them. */
void js_dom_run_page(const char *html, int html_len) {
    if (html_len <= 0 || !html) return;
    const char *p = html;
    const char *end = html + html_len;
    while (p < end) {
        /* find "<script" (case-insensitive), then skip to '>' */
        if (p + 6 <= end &&
            p[0] == '<' &&
            ((p[1] == 's' || p[1] == 'S') &&
             (p[2] == 'c' || p[2] == 'C') &&
             (p[3] == 'r' || p[3] == 'R') &&
             (p[4] == 'i' || p[4] == 'I') &&
             (p[5] == 'p' || p[5] == 'P') &&
             (p[6] == 't' || p[6] == 'T'))) {
            const char *tag = p + 7;
            while (tag < end && *tag != '>') tag++;
            if (tag >= end) break;
            const char *body = tag + 1;
            /* find "</script>" (case-insensitive) */
            const char *close = body;
            while (close + 8 <= end) {
                if (close[0] == '<' && close[1] == '/' &&
                    (close[2] == 's' || close[2] == 'S') &&
                    (close[3] == 'c' || close[3] == 'C') &&
                    (close[4] == 'r' || close[4] == 'R') &&
                    (close[5] == 'i' || close[5] == 'I') &&
                    (close[6] == 'p' || close[6] == 'P') &&
                    (close[7] == 't' || close[7] == 'T')) break;
                close++;
            }
            int body_len = (int)(close - body);
            if (body_len > 0) {
                char *script = (char *)js_malloc(body_len + 1);
                int i;
                for (i = 0; i < body_len; i++) script[i] = body[i];
                script[body_len] = 0;
                js_run(script);
                js_free(script);
            }
            p = close + 8;
        } else {
            p++;
        }
    }
}
