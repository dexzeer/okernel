/*
 * okai JS — kernel glue API (declarations only).
 * Include this from freestanding kernel files (desktop.c) that only need to
 * call the JS engine, without pulling in the host libc shim in js_os.h.
 *
 * "tinyjs ok edition (tm)": substantially rewritten C port of TinyJS.
 * MIT — derived from TinyJS (C) 2009 Pur3 Ltd, Gordon Williams.
 */
#ifndef JS_DOM_H
#define JS_DOM_H

typedef struct js_tiny js_tiny;

extern js_tiny *g_js_engine;
void js_init(void);
void js_run(const char *code);
void js_dom_run_page(const char *html, int html_len);

#endif /* JS_DOM_H */
